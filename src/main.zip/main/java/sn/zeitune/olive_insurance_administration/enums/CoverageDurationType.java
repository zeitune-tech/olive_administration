package sn.zeitune.olive_insurance_administration.enums;

public enum CoverageDurationType {
}
