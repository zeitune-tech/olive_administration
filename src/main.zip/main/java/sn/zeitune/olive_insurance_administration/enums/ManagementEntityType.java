package sn.zeitune.olive_insurance_administration.enums;

public enum ManagementEntityType {
    COMPANY,
    MARKET_LEVEL_ORGANIZATION,
    POINT_OF_SALE
}
