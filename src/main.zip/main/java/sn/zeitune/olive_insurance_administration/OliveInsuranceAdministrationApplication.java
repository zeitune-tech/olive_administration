package sn.zeitune.olive_insurance_administration;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OliveInsuranceAdministrationApplication {

    public static void main(String[] args) {
        SpringApplication.run(OliveInsuranceAdministrationApplication.class, args);
    }

}
