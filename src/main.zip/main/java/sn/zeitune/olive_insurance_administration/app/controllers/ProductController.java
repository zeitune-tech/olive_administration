package sn.zeitune.olive_insurance_administration.app.controllers;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sn.zeitune.olive_insurance_administration.app.dto.requests.ProductRequestDTO;
import sn.zeitune.olive_insurance_administration.app.dto.responses.ProductResponseDTO;
import sn.zeitune.olive_insurance_administration.app.services.ProductService;

import java.util.List;
import java.util.Set;
import java.util.UUID;

@RestController
@RequestMapping("/products")
@RequiredArgsConstructor
public class ProductController {

    private final ProductService productService;

    @PostMapping
    public ResponseEntity<ProductResponseDTO> create(
            @RequestParam UUID ownerUuid,
            @RequestParam(name = "public") boolean isPublic,
            @Valid @RequestBody ProductRequestDTO dto
    ) {
        return ResponseEntity.ok(productService.createProduct(dto, ownerUuid, isPublic));
    }

    @PutMapping("/{uuid}")
    public ResponseEntity<ProductResponseDTO> update(
            @PathVariable UUID uuid,
            @Valid @RequestBody ProductRequestDTO dto
    ) {
        return ResponseEntity.ok(productService.updateProduct(uuid, dto));
    }

    @GetMapping("/{uuid}")
    public ResponseEntity<ProductResponseDTO> getByUuid(@PathVariable UUID uuid) {
        return ResponseEntity.ok(productService.getByUuid(uuid));
    }

    @GetMapping
    public ResponseEntity<List<ProductResponseDTO>> getAll() {
        return ResponseEntity.ok(productService.getAll());
    }

    @PatchMapping("/{uuid}/share")
    public ResponseEntity<Void> sharePublicProduct(
            @PathVariable UUID uuid,
            @RequestBody Set<UUID> companyUuids
    ) {
        productService.sharePublicProductWithCompanies(uuid, companyUuids);
        return ResponseEntity.noContent().build();
    }
}
