package sn.zeitune.olive_insurance_administration.app.services;

import sn.zeitune.olive_insurance_administration.app.dto.requests.ProductRequestDTO;
import sn.zeitune.olive_insurance_administration.app.dto.responses.ProductResponseDTO;

import java.util.List;
import java.util.Set;
import java.util.UUID;

public interface ProductService {

    ProductResponseDTO createProduct(ProductRequestDTO dto, UUID ownerUuid, boolean isPublic);
    ProductResponseDTO updateProduct(UUID uuid, ProductRequestDTO dto);
    void sharePublicProductWithCompanies(UUID productUuid, Set<UUID> companyUuids);
    ProductResponseDTO getByUuid(UUID uuid);
    List<ProductResponseDTO> getAll();
}
