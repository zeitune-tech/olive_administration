package sn.zeitune.olive_insurance_administration.app.dto.responses;

import java.util.Set;
import java.util.UUID;

public record CompanyLevelOrganizationResponseDTO(
        Long id,
        UUID uuid,
        String name,
        String description,
        UUID companyUuid,
        String companyName,
        Set<PointOfSaleResponseDTO> pointsOfSale
) {}
