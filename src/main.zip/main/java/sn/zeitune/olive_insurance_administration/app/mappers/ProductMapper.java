package sn.zeitune.olive_insurance_administration.app.mappers;

import sn.zeitune.olive_insurance_administration.app.dto.requests.ProductRequestDTO;
import sn.zeitune.olive_insurance_administration.app.dto.responses.ProductResponseDTO;
import sn.zeitune.olive_insurance_administration.app.entities.Branch;
import sn.zeitune.olive_insurance_administration.app.entities.product.Product;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.ManagementEntity;

import java.util.UUID;

public class ProductMapper {

    public static Product map(
            ProductRequestDTO dto,
            Branch branch,
            ManagementEntity owner,
            Product product // si c’est une update, sinon passe un constructeur
    ) {
        product.setBranch(branch);
        product.setOwner(owner);
        product.setMinRisk(dto.minRisk());
        product.setMaxRisk(dto.maxRisk());
        product.setMinimumGuaranteeNumber(dto.minimumGuaranteeNumber());
        product.setFleet(dto.fleet());
        product.setHasReduction(dto.hasReduction());
        return product;
    }

    public static ProductResponseDTO map(Product product) {
        UUID branchUuid = product.getBranch() != null ? product.getBranch().getUuid() : null;
        String branchName = product.getBranch() != null ? product.getBranch().getName() : null;

        UUID ownerUuid = product.getOwner() != null ? product.getOwner().getUuid() : null;
        String ownerName = product.getOwner() != null ? product.getOwner().getName() : null;

        return new ProductResponseDTO(
                product.getUuid(),
                branchUuid,
                branchName,
                ownerUuid,
                ownerName,
                product.getMinRisk(),
                product.getMaxRisk(),
                product.getMinimumGuaranteeNumber(),
                product.getFleet(),
                product.isHasReduction()
        );
    }
}
