package sn.zeitune.olive_insurance_administration.app.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.zeitune.olive_insurance_administration.app.clients.UserClient;
import sn.zeitune.olive_insurance_administration.app.dto.external.CreateUserRequest;
import sn.zeitune.olive_insurance_administration.app.dto.requests.CompanyRequestDTO;
import sn.zeitune.olive_insurance_administration.app.dto.responses.CompanyResponseDTO;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.Company;
import sn.zeitune.olive_insurance_administration.app.exceptions.NotFoundException;
import sn.zeitune.olive_insurance_administration.app.mappers.CompanyMapper;
import sn.zeitune.olive_insurance_administration.app.repositories.CompanyRepository;
import sn.zeitune.olive_insurance_administration.app.services.CompanyService;
import sn.zeitune.olive_insurance_administration.app.specifications.CompanySpecification;
import sn.zeitune.olive_insurance_administration.enums.ManagementEntityType;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Transactional
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;
    private final UserClient userClient;

    @Override
    public CompanyResponseDTO create(CompanyRequestDTO dto) {
        Company company = CompanyMapper.map(dto, new Company());
        Company saved = companyRepository.save(company);

        if (saved.getEmail() != null && !saved.getEmail().isBlank()) {
            CreateUserRequest userRequest = new CreateUserRequest(
                    saved.getEmail(),
                    saved.getName(),
                    "COMPANY_ADMIN",
                    saved.getUuid(),
                    ManagementEntityType.COMPANY
            );
            userClient.createUser(userRequest);
        }

        return CompanyMapper.map(saved);
    }

    @Override
    public CompanyResponseDTO update(UUID uuid, CompanyRequestDTO dto) {
        Company company = companyRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Company not found"));
        CompanyMapper.map(dto, company);
        return CompanyMapper.map(companyRepository.save(company));
    }

    @Override
    public void delete(UUID uuid) {
        Company company = companyRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Company not found"));
        companyRepository.delete(company);
    }

    @Override
    public CompanyResponseDTO getByUuid(UUID uuid) {
        Company company = companyRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Company not found"));
        return CompanyMapper.map(company);
    }

    @Override
    public List<CompanyResponseDTO> getAll() {
        return companyRepository.findAll().stream()
                .map(CompanyMapper::map)
                .collect(Collectors.toList());
    }

    @Override
    public Page<CompanyResponseDTO> search(String name, String acronym, String email, Pageable pageable) {
        return companyRepository
                .findAll(CompanySpecification.withFilters(name, acronym, email), pageable)
                .map(CompanyMapper::map);
    }

}
