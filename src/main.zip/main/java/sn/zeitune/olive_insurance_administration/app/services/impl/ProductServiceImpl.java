package sn.zeitune.olive_insurance_administration.app.services.impl;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sn.zeitune.olive_insurance_administration.app.dto.requests.ProductRequestDTO;
import sn.zeitune.olive_insurance_administration.app.dto.responses.ProductResponseDTO;
import sn.zeitune.olive_insurance_administration.app.entities.Branch;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.Company;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.ManagementEntity;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.MarketLevelOrganization;
import sn.zeitune.olive_insurance_administration.app.entities.product.PrivateProduct;
import sn.zeitune.olive_insurance_administration.app.entities.product.Product;
import sn.zeitune.olive_insurance_administration.app.entities.product.PublicProduct;
import sn.zeitune.olive_insurance_administration.app.exceptions.BusinessException;
import sn.zeitune.olive_insurance_administration.app.exceptions.NotFoundException;
import sn.zeitune.olive_insurance_administration.app.mappers.ProductMapper;
import sn.zeitune.olive_insurance_administration.app.repositories.*;
import sn.zeitune.olive_insurance_administration.app.services.ProductService;

import java.util.*;
import java.util.stream.Collectors;

@Service
@Transactional
@RequiredArgsConstructor
public class ProductServiceImpl implements ProductService {

    private final BranchRepository branchRepository;
    private final CompanyRepository companyRepository;
    private final ProductRepository productRepository;
    private final ManagementEntityRepository entityRepository;

    @Override
    public ProductResponseDTO createProduct(ProductRequestDTO dto, UUID ownerUuid, boolean isPublic) {
        Branch branch = branchRepository.findByUuid(dto.branchUuid())
                .orElseThrow(() -> new NotFoundException("Branch not found"));

        ManagementEntity owner = entityRepository.findByUuid(ownerUuid)
                .orElseThrow(() -> new NotFoundException("Owner entity not found"));

        Product product;

        if (isPublic) {
            if (!(owner instanceof MarketLevelOrganization)) {
                throw new BusinessException("Only MarketLevelOrganizations can create public products");
            }
            product = new PublicProduct();
        } else {
            if (!(owner instanceof Company)) {
                throw new BusinessException("Only Companies can create private products");
            }
            product = new PrivateProduct();
        }

        ProductMapper.map(dto, branch, owner, product);
        return ProductMapper.map(productRepository.save(product));
    }

    @Override
    public ProductResponseDTO updateProduct(UUID uuid, ProductRequestDTO dto) {
        Product product = productRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Product not found"));

        Branch branch = branchRepository.findByUuid(dto.branchUuid())
                .orElseThrow(() -> new NotFoundException("Branch not found"));

        if (dto.ownerUuid() != null && !dto.ownerUuid().equals(product.getOwner().getUuid())) {
            throw new BusinessException("Product owner cannot be changed.");
        }

        ProductMapper.map(dto, branch, product.getOwner(), product);

        return ProductMapper.map(productRepository.save(product));
    }



    @Override
    public void sharePublicProductWithCompanies(UUID productUuid, Set<UUID> companyUuids) {
        PublicProduct product = (PublicProduct) productRepository.findByUuid(productUuid)
                .filter(p -> p instanceof PublicProduct)
                .orElseThrow(() -> new NotFoundException("Public product not found"));

        Set<Company> companies = new HashSet<>(companyRepository.findAllByUuidIn(companyUuids));
        if (companies.isEmpty()) throw new NotFoundException("No valid companies found");

        product.getSharedWithCompanies().addAll(companies);
        productRepository.save(product);
    }

    @Override
    public ProductResponseDTO getByUuid(UUID uuid) {
        Product product = productRepository.findByUuid(uuid)
                .orElseThrow(() -> new NotFoundException("Product not found"));
        return ProductMapper.map(product);
    }

    @Override
    public List<ProductResponseDTO> getAll() {
        return productRepository.findAll().stream()
                .map(ProductMapper::map)
                .collect(Collectors.toList());
    }
}
