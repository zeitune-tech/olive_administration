package sn.zeitune.olive_insurance_administration.app.clients.impl;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import sn.zeitune.olive_insurance_administration.app.clients.UserClient;
import sn.zeitune.olive_insurance_administration.app.dto.external.CreateUserRequest;

@Component
@RequiredArgsConstructor
@Slf4j
public class UserClientImpl implements UserClient {

    private final WebClient userWebClient; // injecté depuis config

    @Override
    public void createUser(CreateUserRequest request) {
        try {
            userWebClient.post()
                    .uri("/api/users")
                    .bodyValue(request)
                    .retrieve()
                    .toBodilessEntity()
                    .block();

            log.info("✅ User created for company: {}", request.email());
        } catch (Exception e) {
            log.error("❌ Failed to create user for company: {}", request.email(), e);
            // tu peux rethrow ici si tu veux fail hard
        }
    }
}
