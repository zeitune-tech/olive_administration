package sn.zeitune.olive_insurance_administration.app.dto.responses;

import java.util.UUID;

public record ProductResponseDTO(
        UUID uuid,
        UUID branchUuid,
        String branchName,
        UUID ownerUuid,
        String ownerName,
        Integer minRisk,
        Integer maxRisk,
        Integer minimumGuaranteeNumber,
        Boolean fleet,
        boolean hasReduction
) {}
