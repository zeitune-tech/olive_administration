package sn.zeitune.olive_insurance_administration.app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.CompanyMarketLevelOrganizations;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.Company;
import sn.zeitune.olive_insurance_administration.app.entities.managemententity.MarketLevelOrganization;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface CompanyMarketLevelOrganizationRepository
        extends JpaRepository<CompanyMarketLevelOrganizations, Long> {

    Optional<CompanyMarketLevelOrganizations> findByUuid(UUID uuid);
    void deleteByCompanyAndMarketLevelOrganization(Company company, MarketLevelOrganization organization);
    Optional<CompanyMarketLevelOrganizations> findByCompanyAndMarketLevelOrganization(Company company, MarketLevelOrganization organization);

    boolean existsByCompanyAndMarketLevelOrganization(Company company, MarketLevelOrganization organization);

    List<CompanyMarketLevelOrganizations> findAllByMarketLevelOrganization(MarketLevelOrganization organization);

    List<CompanyMarketLevelOrganizations> findAllByCompany(Company company);
}
