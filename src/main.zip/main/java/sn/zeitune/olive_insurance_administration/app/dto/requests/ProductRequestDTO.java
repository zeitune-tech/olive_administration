package sn.zeitune.olive_insurance_administration.app.dto.requests;

import jakarta.validation.constraints.*;
import java.util.UUID;

public record ProductRequestDTO(
        @NotNull(message = "Branch UUID is required")
        UUID branchUuid,

        @NotNull(message = "Owner UUID is required")
        UUID ownerUuid,

        @Min(value = 1, message = "Minimum risk must be at least 1")
        Integer minRisk,

        @Min(value = 1, message = "Maximum risk must be at least 1")
        Integer maxRisk,

        @Min(value = 1, message = "Minimum guarantee number must be at least 1")
        Integer minimumGuaranteeNumber,

        @NotNull(message = "Fleet must be specified")
        Boolean fleet,

        boolean hasReduction
) {}
